# My-own-malloc-in-C
Write my own malloc function using c language.
